from django.apps import AppConfig


class DjangoConfig(AppConfig):
    name = 'Django'
