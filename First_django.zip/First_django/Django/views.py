from django.shortcuts import render, HttpResponse, redirect


def index(request):
    return HttpResponse("placeholder to later display a list of all blogs")

def new(request):
    return HttpResponse("placeholder to display a new form to create a new blog")

def create(request):
    return redirect('/')

def number(request, my_val):
    return HttpResponse(f"placeholder to edit blog {my_val} with a method named!")

def edit(request,my_val):
    return HttpResponse(f"placeholder to edit blog {my_val} with a method named Edit!")

def destroy(request, my_val):
    return redirect('/')

def id(request, id):
    return HttpResponse("This is gone!")

# Create your views here.
