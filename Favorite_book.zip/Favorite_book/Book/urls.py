from django.urls import path 
from . import views

urlpatterns = [
    path('', views.index),
    path('register',views.register),
    path('login',views.login),
    path('success',views.success),
    path('logout',views.logout),
    path('add_book', views.add_book),
    path('view_book/<int:id>', views.view_book),
    path('edit/<int:id>',views.edit),
    path('delete/<int:id>', views.delete),
    path('like/<int:id>',views.like)
]
