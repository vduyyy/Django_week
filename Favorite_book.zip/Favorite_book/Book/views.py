from django.shortcuts import render, redirect
from django.contrib import messages 
import bcrypt 
from .models import * 


def index(request):
    return render(request,"index.html")


def register(request):
    print("making new user")
    errors = User.objects.basic_validator(request.POST)
    if len(errors)>0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        if request.method=="POST":
            password = request.POST['password']
            pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
            create_user = User.objects.create(first_name= request.POST["first_name"], last_name= request.POST["last_name"], email=request.POST["email"], password=pw_hash)
            request.session['user_id']= create_user.id
            create_user.save()
            return redirect('/success')


def login(request):
    print("you logging in")
    if request.method=="POST":
        user = User.objects.filter(email=request.POST['email'])
        if user:
            logged_user = user[0]
            if bcrypt.checkpw(request.POST['password'].encode(),logged_user.password.encode()):
                request.session['user_id']= logged_user.id
                return render(request,"books.html")
        return redirect("/")


def success(request):
    context={
        "user":User.objects.get(id=request.session['user_id']),
        "all_books": Book.objects.all(),
        "favorites": Favorite.objects.all()
    }
    return render(request, "books.html", context)


def logout(request):
    request.session.clear()
    return redirect('/')

def add_book(request):
    print("You are adding a book")
    if request.session['user_id']:
        title= request.POST['title']
        user= User.objects.get(id=request.session['user_id'])
        description= request.POST['description']
        book= Book.objects.create(
            title=title,
            description=description,
            uploaded_by=user)
        fav= Favorite.objects.create(user_fav=user, book_fav=book)
        return redirect('/success')


def view_book(request, id):
    print("You on the view book")
    if request.session['user_id']:
      context={
        'view_book':Book.objects.get(id=id),
        'user':User.objects.get(id=request.session['user_id'])
    }
    return render(request, "views.html",context)


def edit(request,id): 
    if request.session['user_id']:
        edit_book = Book.objects.get(id=id)
        edit_book.title = request.POST['title']
        edit_book.description = request.POST['description']
        edit_book.save()
        return redirect('/success')

def delete(request, id):
    if request.method=="GET":
        book = Book.objects.get(id=id)
        book.delete()
        return redirect('/success')

def like(request, id):
    print("You liked a Book")
    if request.session['user_id']:
        user = User.objects.get(id= request.session['user_id'])
        view_book= Book.objects.get(id=id)
        Book_fav = Favorite.objects.create(user_fav=user, book_fav=view_book)
        return redirect('/success')


