from django.shortcuts import render, redirect, HttpResponse
from .models import *

def index(request):
    return render(request, "index.html")

def register(request):
    print("You creating a new User")
    errors = User.objects.basic_validator(request.POST)
    if len(errors)> 0:
        for key,value in errors.items():
            messages.error(request,value)
        return redirect('/')
    else:
        if request.method=="POST":
            password = request.POST['password']
            pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
            create_user = User.objects.create(first_name= request.POST["first_name"], last_name= request.POST["last_name"], email=request.POST["email"], password=pw_hash)
            request.session['user_id']= create_user.id
            create_user.save()
            return redirect('/success')

def login(request):
    if request.method=="POST":
        user = User.objects.filter(email=request.POST['email'])
        if user:
            logged_user = user[0]
            if bcrypt.checkpw(request.POST['password'].encode(),logged_user.password.encode()):
                request.session['user_id']= logged_user.id
                return render(request,"success.html")
        return redirect("/")

def success(request):
    #date = user.created_at.strftime('%d %B,%Y')
    context = {
        'user':User.objects.get(id=request.session['user_id']),
        #'date_time':date,
        'post_message':Message.objects.all(),
        'post_comment':Comment.objects.all(),

    }
    return render(request,'success.html',context)


def add_message(request):
    Message.objects.create(message=request.POST['add_message'], user=User.objects.get(id=request.session['user_id']))
    print("you wrote something")
    return redirect('/success')

def delete(request, id):
    erase_post = Message.objects.get(id=id)
    erase_post.delete()
    return redirect('/success')

def comment(request):
    if request.method == 'POST':
        user=User.objects.get(id=request.session['user_id'])
        message=Message.objects.get(id=request.POST['message_id'])
        Comment.objects.create(comment=request.POST['comment'],
        user=user,message=message)
        return redirect('/success')


def logout(request):
    request.session.clear()
    return redirect('/')

