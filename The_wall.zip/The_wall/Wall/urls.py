from django.urls import path
from . import views

urlpatterns = [
    path('',views.index),
    path('register', views.register),
    path('login',views.login),
    path('add_message', views.add_message),
    path('success', views.success),
    path('delete/<id>',views.delete),
    path('comment', views.comment),
    path('logout', views.logout)
]
