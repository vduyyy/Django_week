from __future__ import unicode_literals
from django.db import models
import re
import bcrypt
from django.contrib import messages


class UserManager(models.Manager):
    def basic_validator(self,postData):
        errors ={}
        if len(postData['first_name']) < 2:
            errors['first_name'] = "First Name must be at least 2 characters long"
        if len(postData['last_name']) < 2:
            errors['last_name'] = "Last Name must be at least 2 characters long"
        if len(postData['password']) <5:
            errors['password'] = "Password is too weak"
        Email_regex = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

        if not Email_regex.match(postData['email']):

            errors['email']= "Invalid email address"
        return errors




class User(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email= models.CharField(max_length=255)
    password=models.CharField(max_length=255)
    objects=UserManager()

class Message(models.Model):
    message = models.TextField()
    user = models.ForeignKey(User, related_name='messages', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True) 
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

class Comment(models.Model):
    comment = models.TextField()
    user = models.ForeignKey(User, related_name='user_comments',on_delete=models.CASCADE)
    message = models.ForeignKey(Message, related_name='m_comments',on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True) 
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()
