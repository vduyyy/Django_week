from django.apps import AppConfig


class UserListConfig(AppConfig):
    name = 'user_list'
