from time_display.urls import path
from . import views


urlpatterns = [
    path('', views.index), 
]