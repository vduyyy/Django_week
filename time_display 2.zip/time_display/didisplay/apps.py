from django.apps import AppConfig


class DidisplayConfig(AppConfig):
    name = 'didisplay'
