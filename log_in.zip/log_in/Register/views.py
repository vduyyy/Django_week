from django.shortcuts import render, redirect, HttpResponse
from .models import *




def index(request):
    return render(request, "index.html")

def register(request):
    print("You creating a new User")
    errors = User.objects.basic_validator(request.POST)
    if len(errors)> 0:
        for key,value in errors.items():
            messages.error(request,value)
        return redirect('/')
    else:
        if request.method=="POST":
            password = request.POST['password']
            pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
            create_user = User.objects.create(first_name= request.POST["first_name"], last_name= request.POST["last_name"], email=request.POST["email"], password=pw_hash)
            request.session['user_id']= create_user.id
            create_user.save()
            return redirect('/success')

def success(request):
    print("You finish")
    context={
        "create_user": User.objects.get(id=request.session['user_id'])
    }
    return render(request,"success.html", context)

def login(request):
    if request.method=="POST":
        user = User.objects.filter(email=request.POST['email'])
        if user:
            logged_user = user[0]
            if bcrypt.checkpw(request.POST['password'].encode(),logged_user.password.encode()):
                request.session['userid']= logged_user.id
                return render(request,"log_in.html")
        return redirect("/")


def logout(request):
    request.session.clear()
    return redirect('/')
# Create your views here.
