from __future__ import unicode_literals
from django.db import models
import re
import bcrypt
from django.contrib import messages


class UserManager(models.Manager):
    def basic_validator(self,postData):
        errors ={}
        if len(postData['first_name']) < 2:
            errors['first_name'] = "First Name must be at least 2 characters long"
        if len(postData['last_name']) < 2:
            errors['last_name'] = "Last Name must be at least 2 characters long"
        if len(postData['password']) >5:
            errors['password'] = "Password is too weak"
        Email_regex = re.compile(r'^[a-zA-Z0-9].+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not Email_regex.match(postData['email']):
            errors['email']= "Invalid email address"
        return errors




class User(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email= models.CharField(max_length=255)
    password=models.CharField(max_length=255)
    objects=UserManager()

# Create your models here.
