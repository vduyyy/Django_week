from django.apps import AppConfig


class TvShowConfig(AppConfig):
    name = 'Tv_show'
