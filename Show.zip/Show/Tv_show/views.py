from django.shortcuts import render, HttpResponse, redirect
from .models import *


def index(request):
    return redirect("/shows")
def shows(request):
    all_shows = Show.objects.all()
    context = {
        "all_shows_html": all_shows
    }
    return render(request, "index.html", context)

def new_show(request):
    return render(request, "addnew.html")

def add_new_show(request):
    new_show = Show.objects.create(title=request.POST["title"], network=request.POST["network"], release_date=request.POST["release_date"], desc = request.POST["desc"])
    new_show_id = new_show.id
    return redirect(f"/shows/{new_show_id}")

def display_show(request, show_id):
    new_show = Show.objects.get(id=show_id)
    format_release = new_show.release_date.strftime('%d %B, %Y')
    context = {
        "release_date_html": format_release,
        "show_html": new_show,
    }
    return render(request, "shows.html", context)

def edit_show(request, show_id):
    show = Show.objects.get(id=show_id)
    context= {
        "show_html": show,
    }
    return render(request, "editshow.html", context)

def process_edit(request, show_id):
    show = Show.objects.get(id=show_id)
    show.title= request.POST['title']
    show.network = request.POST['network']
    show.release_date= request.POST['release_date']
    show.description = request.POST['desc']
    show.save()
    return redirect("/shows")

def remove_show(request, show_id):
    
    show = Show.objects.get(id=show_id)
    show.delete()
    
    return redirect("/shows")
