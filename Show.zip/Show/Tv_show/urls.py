from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('shows', views.shows),
    path('shows/new', views.new_show),
    path('shows/new/add', views.add_new_show),
    path('shows/<show_id>', views.display_show),
    path('shows/<show_id>/edit', views.edit_show),
    path('shows/<show_id>/edit/process', views.process_edit),
    path('shows/<show_id>/delete', views.remove_show),
]
