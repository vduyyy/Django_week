from django.shortcuts import render, HttpResponse, redirect
from .models import Books, Authors

def index(request):
    print("This is the index rendering")
    context = {
        'books' : Books.objects.all()
    }
    return render(request, "index.html", context)

def add_book(request):
    print("processing new book")
    new_book = Books.objects.create(title = request.POST['title'], desc = request.POST['desc'])
    return redirect('/')

def show_book(request, id):
    print("this is the book info page")
    context = {
        'books' : Books.objects.get(id = id),
        'authors' : Books.objects.get(id = id).authors.all(),
        'all_authors' : Authors.objects.all(),
    }
    return render(request, "show_book.html", context)


def authors(request):
    print("This is the authors rendering")
    context = {
        'authors' : Authors.objects.all()
    }
    return render(request, "author.html", context)

def add_author(request):
    print("processing new author")
    new_author = Authors.objects.create(first_name = request.POST['fname'], last_name = request.POST['lname'], notes = request.POST['notes'])
    return redirect('/authors')


def author_info(request, id):
    print("this is the author info page")
    context = {
        'authors' : Authors.objects.get(id = id),
        'books' : Authors.objects.get(id = id).books.all(),
        'all_books' : Books.objects.all(),
    }
    return render(request, "author_info.html", context)






