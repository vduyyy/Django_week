from django.apps import AppConfig


class DojoConfig(AppConfig):
    name = 'Dojo'
