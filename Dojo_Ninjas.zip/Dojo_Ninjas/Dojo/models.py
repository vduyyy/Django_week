from django.db import models


class Dojo(models.Model):
    name =models.CharField(max_length=45)
    description = models.TextField(default="Old Dojo")
    city =models.CharField(max_length=45)
    state =models.CharField(max_length=45)
    created_at =models.DateTimeField(auto_now_add=True)
    updated_at =models.DateTimeField(auto_now=True)




class Ninjas(models.Model):
    first_name =models.CharField(max_length=45)
    last_name =models.CharField(max_length=45)
    dojo =models.ForeignKey(Dojo,related_name="ninjas", on_delete= models.CASCADE)
    created_at =models.DateTimeField(auto_now_add=True)
    updated_at =models.DateTimeField(auto_now=True)
    



# Create your models here.
