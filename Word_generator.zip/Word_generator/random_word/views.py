from django.shortcuts import render, HttpResponse, redirect
from django.utils.crypto import get_random_string



def index(request):
    return render(request, 'index.html')

def random(request):
    if 'count' not in request.session:
        request.session['count'] = 0
    request.session['count'] += 1
    
    unique_id = get_random_string(length= 14)
    print(unique_id)
    context = {
        "random":unique_id, 
        "count":request.session['count'],
    }

    return render(request, 'index.html',context)


def reset(request):
    del request.session['count']
    return redirect('/')

# Create your views here.
