from django.apps import AppConfig


class WizardListConfig(AppConfig):
    name = 'wizard_list'
