from django.shortcuts import render, HttpResponse, redirect
import random 
from django import template 
from datetime import datetime




def index(request):
    if 'total' not in request.session: 
        request.session['total'] = 0
    if 'activity' not in request.session:
        request.session['activity'] = []
    
    context = { 
        "total":request.session['total'],
        "activity": request.session['activity'],
}

    return render(request, 'index.html',context)

def gold(request):
    if request.method =="POST":
        if request.POST['building'] == 'Farm':
            gold = random.randint(10,20)
            request.session['activity'].append('Earned ' + str(gold) + ' golds from the ' + request.POST['building'] + ' ' + '(' + str(datetime.now().strftime("%Y-%m-%d %H:%M")) + ')')
        if request.POST['building'] == 'Cave':
            gold = random.randint(5,10)
            request.session['activity'].append('Earned ' + str(gold) + ' golds from the ' + request.POST['building'] + ' ' + '(' + str(datetime.now().strftime("%Y-%m-%d %H:%M")) + ')')
        if request.POST['building'] == 'House':
            gold = random.randint(2,10)
            request.session['activity'].append('Earned ' + str(gold) + ' golds from the ' + request.POST['building'] + ' ' + '(' + str(datetime.now().strftime("%Y-%m-%d %H:%M")) + ')')
        if request.POST['building'] == 'Casino':
            gold = random.randint(-50,51)
            if gold >=0:
                request.session['activity'].append('Enter a casino and earned ' + str(gold) + ' golds from the ' + request.POST['building'] + ' ' + '(' + str(datetime.now().strftime("%Y-%m-%d %H:%M")) + ')')
            else: 
                request.session['activity'].append('Enter a casino and lost ' + str(gold) + ' golds from the ' + request.POST['building'] + ' ' + '(' + str(datetime.now().strftime("%Y-%m-%d %H:%M")) + ')')
        request.session['total'] += gold
    print('This is working!')

    return redirect('/')


def reset(request):
    if request.method == "POST":
        request.session['total'] = 0
        request.session['activity']= []
    return redirect('/')



# Create your views here.
